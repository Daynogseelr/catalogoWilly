<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Etiqueta</title>
    <style>
         body {
            font-family: sans-serif;
            margin: -35px;
            padding: 0;
            font-size: 9px;
        }

        .label-container {
            width: 4.8cm;
            max-height: 1cm;
            display: flex;
            flex-direction: column;
           /* border: 1px solid red; */
        }
        .product-info {
            height: 0.8cm; /* Altura fija de 1cm */
            overflow: hidden; /* Oculta el texto que se desborda */
            text-overflow: ellipsis; /* Agrega puntos suspensivos (...) si el texto se desborda */
            /* border: 1px solid blue;*/
        }

        .barcode {
            height: 0.2cm; /* Altura fija de 0.5cm */
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            /* border: 1px solid green;*/
        }

        img {
            width: 2cm;/* Ancho máximo de 3cm */
            max-height: 0.5cm; /* Alto máximo de 0.5cm */
            vertical-align: middle;
        }
    </style>
</head>
<body>
    @foreach ($labels as $label)
        @if($label)
            @for ($i = 0; $i < $label['quantity']; $i++)
                @php
                    $nombre = $label['name'];
                    $nombreCorto = mb_substr($nombre, 0, 50);
                    if (mb_strlen($nombre) > 50) $nombreCorto .= '...';
                @endphp
                @if(($format ?? 'compact') === 'big')
                    <div style="width:100%; text-align:center; font-family: sans-serif;">
                        <div style="font-size:12px; font-weight:600; margin-top:4px;">{{ strtoupper($nombreCorto) }}</div>
                        <div style="border-top:1px solid #000; margin:6px 0;"></div>
                        <div style="font-size:10px;">Und x {{ $label['quantity'] }}</div>
                        <div style="font-size:28px; font-weight:700; margin:6px 0;">Ref {{ isset($label['price']) ? number_format($label['price'], 2, ',', '.') : '' }}</div>
                        <div style="margin-top:6px; text-align:center;">
                            <img src="data:image/png;base64,{{ $label['barcodePNG'] }}" style="width:120px; height:auto;"> 
                        </div>
                        <div style="font-size:10px; margin-top:4px;">COD. {{ $label['code'] }}</div>
                    </div>
                @else
                    <div class="label-container">
                        <div class="product-info">
                            {{ $nombreCorto }}
                        </div>
                        <div class="barcode">
                            <span style="font-size:11px; font-weight:700;">Ref {{ number_format($price ?? 0, 2, ',', '.') }}</span> <img src="data:image/png;base64,{{ $barcodePNG }}">  <b>COD. {{ $product->code }} </b> 
                        </div>
                    </div>
                @endif
            @endfor
        @endif
    @endforeach
</body>
</html>