<div class="d-flex justify-content-center">
    <button class="btn btn-info btn-sm btn-view-order" data-id="{{ $id }}" title="Ver pedido">
        <i class="fa-regular fa-eye"></i>
    </button>
</div>


   

    