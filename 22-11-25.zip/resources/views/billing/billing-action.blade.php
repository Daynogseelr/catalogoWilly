<div class="row text-center"> 
    <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6" style="padding:0;">  
        <a style="margin: -6px !important; padding: 5px;"  href="javascript:void(0)" data-toggle="tooltip" onClick="openSelectPriceModal('id', {{ $id }})" data-original-title="Edit" class="edit btn btn-primary"> 
            <i class="fa-solid fa-share"></i>
        </a>
    </div> 
    <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6" style="padding:0;">  
        <a style="margin: -6px !important; padding: 5px; color:white;"  href="javascript:void(0)" data-toggle="tooltip" onClick="mostrarProduct({{ $id }})" data-original-title="Edit" class="edit btn btn-info"> 
            <i class="fa-regular fa-eye"></i>
        </a>
    </div> 
</div>    