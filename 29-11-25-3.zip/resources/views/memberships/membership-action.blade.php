
<div class="row text-center"> 
    <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" style="padding:0;">  
        <a style="margin: -6px !important; padding: 5px; color:white;"  href="javascript:void(0)" data-toggle="tooltip" onClick="verMembership({{ $id }})" data-original-title="Edit" class=" btn btn-info edit"> 
            <i class="fa-regular fa-file-lines"></i>
        </a>
    </div> 
</div>    